import json
import os
import time
from io import BytesIO

import boto3
from PIL import Image

s3 = boto3.client("s3")

MAX_FILE_SIZE = 5 * 1024 * 1024  # 5 MB
ALLOWED_EXTENSIONS = (".jpg", ".jpeg", ".png")

OUTPUT_BUCKET = os.environ.get("OUTPUT_BUCKET")


def resize_image(image, width):
    aspect_ratio = image.height / image.width
    height = int(width * aspect_ratio)
    return image.resize((width, height))


def lambda_handler(event, context):
    start_time = time.time()

    record = event["Records"][0]
    input_bucket = record["s3"]["bucket"]["name"]
    object_key = record["s3"]["object"]["key"]

    print(f"Processing file: {object_key}")

    if not object_key.lower().endswith(ALLOWED_EXTENSIONS):
        raise ValueError("Unsupported file type")

    response = s3.get_object(Bucket=input_bucket, Key=object_key)
    file_size = response["ContentLength"]

    if file_size > MAX_FILE_SIZE:
        raise ValueError("File size exceeds limit")

    image_data = response["Body"].read()
    image = Image.open(BytesIO(image_data))

    resized_image = resize_image(image, 800)
    thumbnail_image = resize_image(image, 200)

    resized_buffer = BytesIO()
    resized_image.save(resized_buffer, format=image.format)
    resized_buffer.seek(0)

    thumbnail_buffer = BytesIO()
    thumbnail_image.save(thumbnail_buffer, format=image.format)
    thumbnail_buffer.seek(0)

    s3.put_object(
        Bucket=OUTPUT_BUCKET,
        Key=f"resized/{object_key}",
        Body=resized_buffer,
        ContentType=response["ContentType"],
    )

    s3.put_object(
        Bucket=OUTPUT_BUCKET,
        Key=f"thumbnail/{object_key}",
        Body=thumbnail_buffer,
        ContentType=response["ContentType"],
    )

    processing_time = time.time() - start_time

    print(
        {
            "file": object_key,
            "original_size": file_size,
            "processing_time_seconds": round(processing_time, 2),
        }
    )

    return {"statusCode": 200, "body": json.dumps("Image processed successfully")}
